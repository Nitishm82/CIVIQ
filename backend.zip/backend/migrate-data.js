const fs = require('fs');
const path = require('path');
const db = require('./db');

async function migrateData() {
    try {
        console.log('Reading db.json...');
        const dbJsonPath = path.join(__dirname, 'db.json');
        const dbJson = JSON.parse(fs.readFileSync(dbJsonPath, 'utf8'));
        const requests = dbJson.requests;

        console.log(`Found ${requests.length} requests to migrate.`);

        for (const req of requests) {
            // Check if request already exists (by ID)
            // Note: db.json IDs are timestamps (numbers), MySQL IDs are auto-increment (numbers)
            // We might want to preserve the ID if possible, or just let MySQL generate new ones.
            // Since the user is complaining about "Request not found", they might be referencing an old ID.
            // Let's try to insert with the specific ID first.

            const requestData = {
                id: req.id,
                service: req.service || 'Unknown',
                department: req.department || 'Unassigned',
                location: req.location || '',
                description: req.description || '',
                priority: req.priority || 'medium',
                phone: req.phone || null,
                status: req.status || 'submitted',
                dateSubmitted: new Date(req.dateSubmitted), // Convert string/timestamp to Date object
                latitude: req.coordinates ? req.coordinates.latitude : null,
                longitude: req.coordinates ? req.coordinates.longitude : null,
                photo: req.photo || null,
                departmentCompleted: req.departmentCompleted || false,
                departmentCompletedAt: req.departmentCompletedAt ? new Date(req.departmentCompletedAt) : null,
                driverCompleted: req.driverCompleted || false,
                assignedTo: req.assignedTo || null,
                history: JSON.stringify(req.history || [])
            };

            // Handle potential duplicate key errors if we run this multiple times
            try {
                await db.query('INSERT INTO requests SET ?', requestData);
                console.log(`Migrated request ID: ${req.id}`);
            } catch (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    console.log(`Request ID ${req.id} already exists. Skipping.`);
                } else {
                    console.error(`Failed to migrate request ID ${req.id}:`, err.message);
                }
            }
        }

        console.log('Migration complete!');
        process.exit(0);
    } catch (err) {
        console.error('Migration failed:', err);
        process.exit(1);
    }
}

migrateData();
