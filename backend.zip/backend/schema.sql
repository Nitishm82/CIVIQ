CREATE TABLE IF NOT EXISTS requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  service VARCHAR(255) NOT NULL,
  department VARCHAR(255) DEFAULT 'Unassigned',
  location TEXT,
  description TEXT,
  priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
  phone VARCHAR(50),
  status ENUM('submitted', 'assigned', 'in-progress', 'completed') DEFAULT 'submitted',
  dateSubmitted DATETIME DEFAULT CURRENT_TIMESTAMP,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  photo LONGTEXT,
  departmentCompleted BOOLEAN DEFAULT FALSE,
  departmentCompletedAt DATETIME,
  driverCompleted BOOLEAN DEFAULT FALSE,
  assignedTo VARCHAR(255),
  history JSON
);
