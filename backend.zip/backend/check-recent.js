const db = require('./db');

async function listRecent() {
    try {
        const [rows] = await db.query('SELECT id, service, status, dateSubmitted FROM requests ORDER BY dateSubmitted DESC LIMIT 5');
        console.log('Most Recent Requests:');
        console.table(rows);
        process.exit(0);
    } catch (err) {
        console.error('Error:', err);
        process.exit(1);
    }
}

listRecent();
