const express = require('express');
const path = require('path');
const cors = require('cors');
const db = require('./db');

const PORT = process.env.PORT || 3000;

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Serve static files from the project root (2 levels up)
const PROJECT_ROOT = path.join(__dirname, '../../');
app.use(express.static(PROJECT_ROOT));

// Serve the main index.html at the root route
app.get('/', (req, res) => {
  res.sendFile(path.join(PROJECT_ROOT, 'index.html'));
});

/** GET all requests **/
app.get('/api/requests', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM requests ORDER BY dateSubmitted DESC');
    // Parse history if it's a string (MySQL JSON type might be returned as object or string depending on driver/config)
    const requests = rows.map(r => ({
      ...r,
      history: typeof r.history === 'string' ? JSON.parse(r.history) : r.history,
      coordinates: { latitude: r.latitude, longitude: r.longitude }
    }));
    res.json(requests);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

/** GET one request **/
app.get('/api/requests/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [rows] = await db.query('SELECT * FROM requests WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found' });

    const r = rows[0];
    const request = {
      ...r,
      history: typeof r.history === 'string' ? JSON.parse(r.history) : r.history,
      coordinates: { latitude: r.latitude, longitude: r.longitude }
    };
    res.json(request);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

/** POST new request **/
app.post('/api/requests', async (req, res) => {
  try {
    const payload = req.body;
    const now = new Date();

    const request = {
      service: payload.service || 'Unknown',
      department: payload.department || 'Unassigned',
      location: payload.location || '',
      description: payload.description || '',
      priority: payload.priority || 'medium',
      phone: payload.phone || null,
      status: 'submitted',
      dateSubmitted: now,
      latitude: payload.coordinates ? payload.coordinates.latitude : null,
      longitude: payload.coordinates ? payload.coordinates.longitude : null,
      photo: payload.photo || null,
      departmentCompleted: false,
      departmentCompletedAt: null,
      driverCompleted: false,
      assignedTo: null,
      history: JSON.stringify(payload.history || [])
    };

    const [result] = await db.query('INSERT INTO requests SET ?', request);

    const newRequest = { ...request, id: result.insertId, history: JSON.parse(request.history) };
    res.status(201).json(newRequest);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

/** PUT update request (replace/patch) **/
app.put('/api/requests/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const payload = req.body;

    // We need to handle partial updates carefully or just update specific fields
    // For simplicity, let's assume payload contains fields to update

    // Prepare update object
    const updateFields = {};
    if (payload.service !== undefined) updateFields.service = payload.service;
    if (payload.department !== undefined) updateFields.department = payload.department;
    if (payload.location !== undefined) updateFields.location = payload.location;
    if (payload.description !== undefined) updateFields.description = payload.description;
    if (payload.priority !== undefined) updateFields.priority = payload.priority;
    if (payload.phone !== undefined) updateFields.phone = payload.phone;
    if (payload.status !== undefined) updateFields.status = payload.status;
    if (payload.coordinates !== undefined) {
      updateFields.latitude = payload.coordinates.latitude;
      updateFields.longitude = payload.coordinates.longitude;
    }
    if (payload.photo !== undefined) updateFields.photo = payload.photo;
    if (payload.departmentCompleted !== undefined) updateFields.departmentCompleted = payload.departmentCompleted;
    if (payload.departmentCompletedAt !== undefined) updateFields.departmentCompletedAt = new Date(payload.departmentCompletedAt);
    if (payload.driverCompleted !== undefined) updateFields.driverCompleted = payload.driverCompleted;
    if (payload.assignedTo !== undefined) updateFields.assignedTo = payload.assignedTo;
    if (payload.history !== undefined) updateFields.history = JSON.stringify(payload.history);

    if (Object.keys(updateFields).length === 0) {
      return res.json({ message: 'No fields to update' });
    }

    await db.query('UPDATE requests SET ? WHERE id = ?', [updateFields, id]);

    // Fetch updated record
    const [rows] = await db.query('SELECT * FROM requests WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found' });

    const r = rows[0];
    const updatedRequest = {
      ...r,
      history: typeof r.history === 'string' ? JSON.parse(r.history) : r.history,
      coordinates: { latitude: r.latitude, longitude: r.longitude }
    };
    res.json(updatedRequest);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

/** Dashboard stats **/
app.get('/api/dashboard-stats', async (req, res) => {
  try {
    const [totalRows] = await db.query('SELECT COUNT(*) as count FROM requests');
    const [pendingRows] = await db.query('SELECT COUNT(*) as count FROM requests WHERE status = "submitted"');
    const [activeRows] = await db.query('SELECT COUNT(*) as count FROM requests WHERE status IN ("in-progress", "assigned")');

    // Completed today
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const [completedRows] = await db.query(
      'SELECT COUNT(*) as count FROM requests WHERE (status = "completed" OR driverCompleted = 1) AND dateSubmitted >= ?',
      [startOfDay]
    );

    res.json({
      total: totalRows[0].count,
      pending: pendingRows[0].count,
      active: activeRows[0].count,
      completedToday: completedRows[0].count
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.listen(PORT, () => {
  console.log(`API server running on http://localhost:${PORT}`);
});

