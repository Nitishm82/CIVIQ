const db = require('./db');

async function listIds() {
    try {
        const [rows] = await db.query('SELECT id FROM requests ORDER BY dateSubmitted DESC LIMIT 10');
        console.log('Valid Request IDs:');
        rows.forEach(row => console.log(row.id));
        process.exit(0);
    } catch (err) {
        console.error('Error:', err);
        process.exit(1);
    }
}

listIds();
