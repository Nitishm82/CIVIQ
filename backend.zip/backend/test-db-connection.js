const db = require('./db');

async function testConnection() {
    try {
        console.log('Testing database connection...');
        const [rows] = await db.query('SELECT 1 as val');
        console.log('Connection successful!', rows);

        console.log('Checking for requests table...');
        const [tables] = await db.query('SHOW TABLES LIKE "requests"');
        if (tables.length > 0) {
            console.log('Requests table exists.');
            const [count] = await db.query('SELECT COUNT(*) as count FROM requests');
            console.log(`Found ${count[0].count} requests.`);
        } else {
            console.log('Requests table does NOT exist.');
        }

        process.exit(0);
    } catch (err) {
        console.error('Connection failed:', err.message);
        process.exit(1);
    }
}

testConnection();
