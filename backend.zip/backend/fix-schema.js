const db = require('./db');

async function fixSchema() {
    try {
        console.log('Altering table requests to modify id column to BIGINT...');
        await db.query('ALTER TABLE requests MODIFY id BIGINT NOT NULL AUTO_INCREMENT');
        console.log('Schema updated successfully.');
        process.exit(0);
    } catch (err) {
        console.error('Schema update failed:', err);
        process.exit(1);
    }
}

fixSchema();
